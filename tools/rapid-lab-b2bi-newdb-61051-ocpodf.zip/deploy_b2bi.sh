#!/bin/bash
## Copyright (C) 2022 Arif Ali
## This program is free software: you can redistribute it and/or modify it under the terms 
## of the GNU General Public License as published by the Free Software Foundation, 
## either version 3 of the License, or (at your option) any later version. 
## This program is distributed in the hope that it will be useful, 
## but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
## or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
## for more details. You should have received a copy of the GNU General Public License 
## along with this program. If not, see https://www.gnu.org/licenses/.

## Exit if there is an error
set -e

## To read env.sh file.
source $(pwd)/env.sh
if [ -z "$APIKEY" ] ; then
  echo "You must provide entitlement key in the env.sh file."
  exit 1
fi
## Create delete file
cat <<\EOF > delete_b2bi.sh
#!/bin/bash
## Copyright (C) 2022 Arif Ali
## This program is free software: you can redistribute it and/or modify it under the terms 
## of the GNU General Public License as published by the Free Software Foundation, 
## either version 3 of the License, or (at your option) any later version. 
## This program is distributed in the hope that it will be useful, 
## but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
## or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
## for more details. You should have received a copy of the GNU General Public License 
## along with this program. If not, see https://www.gnu.org/licenses/.

## Exit out of an error
set -e
## To read env.sh file.
source $(pwd)/env.sh

oc project ${PROJECT_NAME}
helm delete sterling-fg
oc delete scc ibm-b2bi-scc
oc delete clusterrole ibm-b2bi-scc
oc delete ClusterRoleBinding ibm-b2bi-scc
oc delete -f ocs-storage-tools-pod.yaml
oc delete -f ocs-preprovision-pvc.yaml
oc delete project ${PROJECT_NAME}
(rm $PROJECT_DIR/ibm-b2bi-prod/values.yaml)
(mv $PROJECT_DIR/ibm-b2bi-prod/values.yaml.orig $PROJECT_DIR/ibm-b2bi-prod/values.yaml)
(mv $PROJECT_DIR/ibm-b2bi-prod/ $PROJECT_DIR/ibm-b2bi-prod-deleted/)
(rm $PROJECT_DIR/ibm-b2bi-prod-2.0.7.tgz)
EOF
chmod 755 delete_b2bi.sh
## Create new project for B2Bi reading project name from env.sh
oc new-project ${PROJECT_NAME}
## Create yaml file to pre-provision ocs volumes
cat << EOF > ocs-preprovision-pvc.yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: sterling-fg-b2bi-resources
  labels:
    intent: resources
spec:
  accessModes:
    - ReadWriteMany
  persistentVolumeReclaimPolicy: "Delete"
  resources:
    requests:
      storage: 500Mi
  storageClassName: ocs-storagecluster-cephfs
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: sterling-fg-b2bi-logs
  labels:
    intent: logs
spec:
  accessModes:
    - ReadWriteMany
  persistentVolumeReclaimPolicy: "Delete"
  resources:
    requests:
      storage: 1Gi
  storageClassName: ocs-storagecluster-cephfs
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: sterling-fg-b2bi-documents
  labels:
    intent: documents
spec:
  accessModes:
    - ReadWriteMany
  persistentVolumeReclaimPolicy: "Delete"
  resources:
    requests:
      storage: 1Gi
  storageClassName: ocs-storagecluster-cephfs
EOF
## Provision OCS storage devices
oc create -f ocs-preprovision-pvc.yaml 
sleep 30
## Use anyuid SCC to provision the storage tools pod
oc adm policy add-scc-to-user anyuid -z default -n ${PROJECT_NAME}
## Create Yaml file for storage tools pod
cat << EOF > ocs-storage-tools-pod.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ocs-storage-tools-pod
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ocs-storage-tools-pod
  template:
    metadata:
      labels:
        app: ocs-storage-tools-pod
    spec:
      containers:
      - name: ocs-storage-tools-pod
        image: aroute/b2bitoolkit4:latest
        command: ["/bin/bash", "-ce", "tail -f /dev/null"]
        volumeMounts:
        - mountPath: /var/nfs-data/resources
          name: resources-volume
        - mountPath: /var/nfs-data/logs
          name: logs-volume
        - mountPath: /var/nfs-data/documents
          name: documents-volume
      volumes:
      - name: resources-volume
        persistentVolumeClaim:
          claimName: sterling-fg-b2bi-resources
      - name: logs-volume
        persistentVolumeClaim:
          claimName: sterling-fg-b2bi-logs
      - name: documents-volume
        persistentVolumeClaim:
          claimName: sterling-fg-b2bi-documents
      initContainers:
      - name: permissionsfix
        image: alpine:latest
        command: ["/bin/sh", "-c"]
        args:
          - chown 1010:1010 /mount/*;
        volumeMounts:
        - name: resources-volume
          mountPath: /mount/resources
        - name: logs-volume
          mountPath: /mount/logs
        - name: documents-volume
          mountPath: /mount/documents
EOF
## Create storage toolkit pod, attached with the newly created volumes
oc create -f ocs-storage-tools-pod.yaml
sleep 120
## Identify pod name.
export NFS_STORAGE_POD=$(oc get po | grep ocs-storage-tools-pod | awk {'print $1'})
## Setup storage directories and copy the jar file. Wait a minute.
oc rsh pod/${NFS_STORAGE_POD} mkdir -p /var/nfs-data/{resources,logs,documents}
oc rsh pod/${NFS_STORAGE_POD} chmod -R 777 /var/nfs-data/{resources,logs,documents}
oc cp db2jcc4.jar ${NFS_STORAGE_POD}:/var/nfs-data/resources/
sleep 60
## Create yaml file for B2Bi secrets.
cat << EOF > b2bi-secrets.yaml
apiVersion: v1
kind: Secret
metadata:
  name: b2b-system-passphrase-secret
type: Opaque
stringData:
  SYSTEM_PASSPHRASE: password

---

apiVersion: v1
kind: Secret
metadata:
  name: b2b-db-secret
type: Opaque
stringData:
  DB_USER: db2inst1
  DB_PASSWORD: db2inst1
  
---

apiVersion: v1
kind: Secret
metadata:
  name: b2b-jms-secret
type: Opaque
stringData:
  JMS_USERNAME: app
  JMS_PASSWORD: passw0rd
  JMS_KEYSTORE_PASSWORD: passw0rd
  JMS_TRUSTSTORE_PASSWORD: passw0rd

---
apiVersion: v1
kind: Secret
metadata:
  name: b2b-liberty-secret
type: Opaque
stringData:
  LIBERTY_KEYSTORE_PASSWORD: password
EOF
## Provision secrets.
envsubst < b2bi-secrets.yaml | oc create -f -
## Create entitlement secret.
cat <<\EOF > entitledregistry.sh
#!/bin/bash
## To read env.sh file.
source $(pwd)/env.sh
oc create secret docker-registry entitled-registry \
--docker-username=cp \
--docker-password=${APIKEY} \
--docker-email=${EMAIL} \
--docker-server=cp.icr.io -n ${PROJECT_NAME}
EOF
## Read api token from env.sh file for entitlement of certified containers.
chmod 755 entitledregistry.sh ; ./entitledregistry.sh
## Create auto-scaler files
cat << EOF > autoscalers.yaml
kind: HorizontalPodAutoscaler
apiVersion: autoscaling/v2beta2
metadata:
  name: ac-auto-scaler
  namespace: ${PROJECT_NAME}
spec:
  scaleTargetRef:
    kind: StatefulSet
    name: sterling-fg-b2bi-ac-server
    apiVersion: apps/v1
  minReplicas: 1
  maxReplicas: 2
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 90

---
kind: HorizontalPodAutoscaler
apiVersion: autoscaling/v2beta2
metadata:
  name: asi-auto-scaler
  namespace: ${PROJECT_NAME}
spec:
  scaleTargetRef:
    kind: StatefulSet
    name: sterling-fg-b2bi-asi-server
    apiVersion: apps/v1
  minReplicas: 1
  maxReplicas: 2
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 90
EOF
## Identify DB2 and MQ's ClusterIP addresses and OCP Ingress Subdomain
export DB2_IP=$(oc get svc db2-ci -n ${DB2_NAME} -o jsonpath='{.spec.clusterIP}')
export MQ_IP=$(oc get svc mq-data -n ${MQ_NAME} -o jsonpath='{.spec.clusterIP}')
export INGRESS_SUBDOMAIN=$(oc get IngressController default -n openshift-ingress-operator -o jsonpath='{.status.domain}')
# Download/extract Helm Chart version 2.0.7 (latest as of the writing)
wget https://github.com/IBM/charts/raw/master/repo/ibm-helm/ibm-b2bi-prod-2.0.7.tgz
tar xvf ibm-b2bi-prod-2.0.7.tgz
## Setup SCC and RBAC for B2Bi
(cd $PROJECT_DIR/ibm-b2bi-prod/ibm_cloud_pak/pak_extensions/pre-install/clusterAdministration/ ; chmod 755 createSecurityClusterPrereqs.sh ; ./createSecurityClusterPrereqs.sh)
(cd $PROJECT_DIR/ibm-b2bi-prod/ibm_cloud_pak/pak_extensions/pre-install/namespaceAdministration/ ; chmod 755 createSecurityNamespacePrereqs.sh ; ./createSecurityNamespacePrereqs.sh ${PROJECT_NAME})
## Move edited values file to the helm chart directory.
(mv $PROJECT_DIR/ibm-b2bi-prod/values.yaml $PROJECT_DIR/ibm-b2bi-prod/values.yaml.orig)
(cp $PROJECT_DIR/edited-values.yaml $PROJECT_DIR/ibm-b2bi-prod/values.yaml)
## remove the pvc creation templates from the chart as volumes already created
rm ${PROJECT_DIR}/ibm-b2bi-prod/templates/documents-pvc.yaml
rm ${PROJECT_DIR}/ibm-b2bi-prod/templates/logs-pvc.yaml
rm ${PROJECT_DIR}/ibm-b2bi-prod/templates/resources-pvc.yaml
#cd ibm-b2bi-prod
## Deploy Helm chart.
## removing from this version for IBM Cloud Shell based install
#envsubst < $PROJECT_DIR/ibm-b2bi-prod/values.yaml | helm install sterling-fg $PROJECT_DIR/ibm-b2bi-prod --timeout 120m0s --namespace ${PROJECT_NAME} --values -
