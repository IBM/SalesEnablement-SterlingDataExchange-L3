#!/bin/bash
## Locate your APIKEY (Entitlement Key For Container Software) 
## here: https://myibm.ibm.com/products-services/containerlibrary
## Requires IBM ID and permission.
export PROJECT_NAME="b2bi"
export PROJECT_DIR="$HOME/b2bi"
export DB2_NAME="db2"
export MQ_NAME="mq"
export APIKEY=""
export EMAIL=""