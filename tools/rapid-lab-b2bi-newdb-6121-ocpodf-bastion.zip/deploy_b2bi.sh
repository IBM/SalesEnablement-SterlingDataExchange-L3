#!/bin/bash
## Copyright (C) 2022 Arif Ali
## This program is free software: you can redistribute it and/or modify it under the terms 
## of the GNU General Public License as published by the Free Software Foundation, 
## either version 3 of the License, or (at your option) any later version. 
## This program is distributed in the hope that it will be useful, 
## but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
## or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
## for more details. You should have received a copy of the GNU General Public License 
## along with this program. If not, see https://www.gnu.org/licenses/.

## Exit if there is an error
set -e

## To read env.sh file.
source $(pwd)/env.sh
if [ -z "$APIKEY" ] ; then
  echo "You must provide entitlement key in the env.sh file."
  exit 1
fi
## Create delete file
cat <<\EOF > delete_b2bi.sh
#!/bin/bash
## Copyright (C) 2022 Arif Ali
## This program is free software: you can redistribute it and/or modify it under the terms 
## of the GNU General Public License as published by the Free Software Foundation, 
## either version 3 of the License, or (at your option) any later version. 
## This program is distributed in the hope that it will be useful, 
## but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
## or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
## for more details. You should have received a copy of the GNU General Public License 
## along with this program. If not, see https://www.gnu.org/licenses/.

## Exit out of an error
set -e
## To read env.sh file.
source $(pwd)/env.sh

oc project ${PROJECT_NAME}
helm delete sterling-fg
oc delete project ${PROJECT_NAME}
(rm $PROJECT_DIR/ibm-b2bi-prod/values.yaml)
(mv $PROJECT_DIR/ibm-b2bi-prod/values.yaml.orig $PROJECT_DIR/ibm-b2bi-prod/values.yaml)
(mv $PROJECT_DIR/ibm-b2bi-prod/ $PROJECT_DIR/ibm-b2bi-prod-deleted/)
(rm $PROJECT_DIR/ibm-b2bi-prod-2.1.1.tgz)
EOF
chmod 755 delete_b2bi.sh
## Create new project for B2Bi reading project name from env.sh
oc new-project ${PROJECT_NAME}
## Create RBAC for the default SA in the project:
cat << EOF > default-sa-rbac.yaml
kind: Role
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: ibm-b2bi-role-${PROJECT_NAME}
  namespace: ${PROJECT_NAME}
rules:
  - apiGroups: ['route.openshift.io']
    resources: ['routes','routes/custom-host']
    verbs: ['get', 'watch', 'list', 'patch', 'update']
  - apiGroups: ['','batch']
    resources: ['secrets','configmaps','persistentvolumeclaims','pods','services','cronjobs','jobs']
    verbs: ['create', 'get', 'list', 'delete', 'patch', 'update']

---
kind: RoleBinding
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: ibm-b2bi-rolebinding-${PROJECT_NAME}
  namespace: ${PROJECT_NAME}
subjects:
  - kind: ServiceAccount
    name: default
    namespace: ${PROJECT_NAME}
roleRef:
  kind: Role
  name: ibm-b2bi-role-${PROJECT_NAME}
  apiGroup: rbac.authorization.k8s.io
EOF
# apply the RBAC binding for the default SA
envsubst < default-sa-rbac.yaml | oc create -f -
## Create yaml file for B2Bi secrets.
cat << EOF > b2bi-secrets.yaml
apiVersion: v1
kind: Secret
metadata:
  name: b2b-system-passphrase-secret
type: Opaque
stringData:
  SYSTEM_PASSPHRASE: password

---

apiVersion: v1
kind: Secret
metadata:
  name: b2b-db-secret
type: Opaque
stringData:
  DB_USER: db2inst1
  DB_PASSWORD: db2inst1
  
---

apiVersion: v1
kind: Secret
metadata:
  name: b2b-jms-secret
type: Opaque
stringData:
  JMS_USERNAME: app
  JMS_PASSWORD: passw0rd
  JMS_KEYSTORE_PASSWORD: passw0rd
  JMS_TRUSTSTORE_PASSWORD: passw0rd

---
apiVersion: v1
kind: Secret
metadata:
  name: b2b-liberty-secret
type: Opaque
stringData:
  LIBERTY_KEYSTORE_PASSWORD: password
EOF
## Provision secrets.
envsubst < b2bi-secrets.yaml | oc create -f -
## Create entitlement secret.
cat <<\EOF > entitledregistry.sh
#!/bin/bash
## To read env.sh file.
source $(pwd)/env.sh
oc create secret docker-registry entitled-registry \
--docker-username=cp \
--docker-password=${APIKEY} \
--docker-email=${EMAIL} \
--docker-server=cp.icr.io -n ${PROJECT_NAME}
EOF
## Read api token from env.sh file for entitlement of certified containers.
chmod 755 entitledregistry.sh ; ./entitledregistry.sh
## Identify DB2 and MQ's ClusterIP addresses and OCP Ingress Subdomain
export DB2_IP=$(oc get svc db2-ci -n ${DB2_NAME} -o jsonpath='{.spec.clusterIP}')
export MQ_IP=$(oc get svc mq-data -n ${MQ_NAME} -o jsonpath='{.spec.clusterIP}')
export INGRESS_SUBDOMAIN=$(oc get IngressController default -n openshift-ingress-operator -o jsonpath='{.status.domain}')
# Download/extract Helm Chart version 2.1.1 (provides 6.1.2.1)
wget https://github.com/IBM/charts/raw/master/repo/ibm-helm/ibm-b2bi-prod-2.1.1.tgz
tar xvf ibm-b2bi-prod-2.1.1.tgz
## Move edited values file to the helm chart directory.
(mv $PROJECT_DIR/ibm-b2bi-prod/values.yaml $PROJECT_DIR/ibm-b2bi-prod/values.yaml.orig)
(cp $PROJECT_DIR/edited-values.yaml $PROJECT_DIR/ibm-b2bi-prod/values.yaml)
## Deploy Helm chart.
cd ibm-b2bi-prod
envsubst < $PROJECT_DIR/ibm-b2bi-prod/values.yaml | helm install sterling-fg $PROJECT_DIR/ibm-b2bi-prod --timeout 120m0s --namespace ${PROJECT_NAME} --values -
