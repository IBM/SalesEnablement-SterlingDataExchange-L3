#!/bin/bash
## Install IBM Cloud CLI
echo "Installing ibmcloud utility. Wait!"
curl -fsSL https://clis.cloud.ibm.com/install/linux | sh >> /dev/null 2>&1
ibmcloud plugin install container-service -r 'IBM Cloud' >> /dev/null 2>&1

## Install helm
echo "Installing Helm. Wait!"
curl -fsSL -o get_helm.sh https://raw.githubusercontent.com/helm/helm/master/scripts/get-helm-3 >> /dev/null 2>&1
chmod 700 get_helm.sh >> /dev/null 2>&1
bash ./get_helm.sh >> /dev/null 2>&1

## Install OpenShift cli
echo "Installing OpenShift oc utility. Wait!"
mkdir -p oc-client
cd oc-client
wget https://mirror.openshift.com/pub/openshift-v4/clients/ocp/4.11.31/openshift-client-linux.tar.gz >> /dev/null 2>&1
tar xvf openshift-client-linux.tar.gz >> /dev/null 2>&1
sudo mv oc /usr/local/bin/oc >> /dev/null 2>&1
cd .. 

## Install kubernetes cli
echo "Installing Kubernetes kubectl. Wait!"
curl -LO "https://dl.k8s.io/release/v1.24.11/bin/linux/amd64/kubectl" >> /dev/null 2>&1
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl >> /dev/null 2>&1

echo "cleaning up. Wait!"
rm -rf kubectl oc-client get_helm.sh >> /dev/null 2>&1

## Check versions
echo "Checking versions"
oc version --client
helm version --client
kubectl version --short --client=true
ibmcloud version -q