#!/usr/bin/bash
## Copyright (C) 2022 Arif Ali
## This program is free software: you can redistribute it and/or modify it under the terms 
## of the GNU General Public License as published by the Free Software Foundation, 
## either version 3 of the License, or (at your option) any later version. 
## This program is distributed in the hope that it will be useful, 
## but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
## or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
## for more details. You should have received a copy of the GNU General Public License 
## along with this program. If not, see https://www.gnu.org/licenses/.

## Exit if there is an error
set -e

## To read env.sh file.
source $(dirname $(realpath ${0}))/env.sh
if [ -z "$APIKEY" ] ; then
  echo "You must provide entitlement key in the env.sh file."
  exit 1
fi
## Create delete file
cat <<\EOF > delete_b2bi.sh
#!/usr/bin/bash
## Copyright (C) 2022 Arif Ali
## This program is free software: you can redistribute it and/or modify it under the terms 
## of the GNU General Public License as published by the Free Software Foundation, 
## either version 3 of the License, or (at your option) any later version. 
## This program is distributed in the hope that it will be useful, 
## but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
## or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
## for more details. You should have received a copy of the GNU General Public License 
## along with this program. If not, see https://www.gnu.org/licenses/.

## Exit out of an error
set -e
## To read env.sh file.
source $(dirname $(realpath ${0}))/env.sh

oc project ${PROJECT_NAME}
helm delete sterling-fg
oc delete scc ibm-b2bi-scc
oc delete clusterrole ibm-b2bi-scc
oc delete ClusterRoleBinding ibm-b2bi-scc
oc delete pv resources documents logs
export PERSISTENT_VOLUME_NAME=$(oc get pvc ibm-cloud-file-nfs-storage-pvc -n ${PROJECT_NAME} -o jsonpath='{.spec.volumeName}')
export NFS_SERVER_NAME=$(oc get pv ${PERSISTENT_VOLUME_NAME} -n openshift-image-registry -o jsonpath='{.spec.nfs.server}')
export NFS_SERVER_PATH=$(oc get pv ${PERSISTENT_VOLUME_NAME} -n openshift-image-registry -o jsonpath='{.spec.nfs.path}')
envsubst < ibm-cloud-file-nfs-storage-pod.yaml | oc delete -f -
oc delete pvc ibm-cloud-file-nfs-storage-pvc
oc delete project ${PROJECT_NAME}
(rm $PROJECT_DIR/ibm-b2bi-prod/values.yaml)
(mv $PROJECT_DIR/ibm-b2bi-prod/values.yaml.orig $PROJECT_DIR/ibm-b2bi-prod/values.yaml)
(mv $PROJECT_DIR/ibm-b2bi-prod/ $PROJECT_DIR/ibm-b2bi-prod-deleted/)
(rm $PROJECT_DIR/ibm-b2bi-prod-2.0.7.tgz)
EOF
chmod 755 delete_b2bi.sh
## Create new project for B2Bi reading project name from env.sh
oc new-project ${PROJECT_NAME}
## Identify cluster's region and zone.
export CLUSTER_STORAGE_REGION=$(oc get pvc image-registry-storage -n openshift-image-registry -o jsonpath='{.metadata.labels.region}')
export CLUSTER_STORAGE_ZONE=$(oc get pvc image-registry-storage -n openshift-image-registry -o jsonpath='{.metadata.labels.zone}')
## Create yaml file to order IBM Cloud File Storage.
cat << EOF > order-ibm-cloud-file-nfs-storage.yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
     name: ibm-cloud-file-nfs-storage-pvc
labels:
   billingType: hourly
   region: ${CLUSTER_STORAGE_REGION}
   zone: ${CLUSTER_STORAGE_ZONE}
spec:
 accessModes:
   - ReadWriteMany
 persistentVolumeReclaimPolicy: "Delete"
 resources:
   requests:
     storage: 20Gi
 storageClassName: ibmc-file-gold
EOF
## Provision IBM Cloud File storage device (wait few minutes for auto-provisioning to complete)
envsubst < order-ibm-cloud-file-nfs-storage.yaml | oc create -f -
sleep 3m
## Identify new device's Persistent Volume name, server address and path.
export PERSISTENT_VOLUME_NAME=$(oc get pvc ibm-cloud-file-nfs-storage-pvc -n ${PROJECT_NAME} -o jsonpath='{.spec.volumeName}')
export NFS_SERVER_NAME=$(oc get pv ${PERSISTENT_VOLUME_NAME} -n openshift-image-registry -o jsonpath='{.spec.nfs.server}')
export NFS_SERVER_PATH=$(oc get pv ${PERSISTENT_VOLUME_NAME} -n openshift-image-registry -o jsonpath='{.spec.nfs.path}')
## Use anyuid SCC to provision the pod.
oc adm policy add-scc-to-user anyuid -z default -n ${PROJECT_NAME}
## Create Yaml file for toolkit.
cat << EOF > ibm-cloud-file-nfs-storage-pod.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ibm-cloud-file-nfs-storage-pod
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ibm-cloud-file-nfs-storage-pod
  template:
    metadata:
      labels:
        app: ibm-cloud-file-nfs-storage-pod
    spec:
      containers:
      - name: ibm-cloud-file-nfs-storage-pod
        image: aroute/b2bitoolkit4:latest
        command: ["/bin/bash", "-ce", "tail -f /dev/null"]
        volumeMounts:
        - mountPath: /var/nfs-data
          name: volume
      volumes:
      - name: volume
        persistentVolumeClaim:
          claimName: ibm-cloud-file-nfs-storage-pvc
      initContainers:
      - name: permissionsfix
        image: alpine:latest
        command: ["/bin/sh", "-c"]
        args:
          - chown 1010:1010 /mount;
        volumeMounts:
        - name: volume
          mountPath: /mount
EOF
## Create NFS toolkit pod, attached with the newly created File storage device. Wait few minutes.
envsubst < ibm-cloud-file-nfs-storage-pod.yaml | oc create -f -
sleep 2m
## Identify pod name.
export NFS_STORAGE_POD=$(oc get po | grep ibm-cloud-file-nfs-storage-pod | awk {'print $1'})
## Setup storage directories and copy the jar file. Wait a minute.
oc rsh pod/${NFS_STORAGE_POD} mkdir -p /var/nfs-data/{resources,logs,documents}
oc rsh pod/${NFS_STORAGE_POD} chmod -R 777 /var/nfs-data/{resources,logs,documents}
oc cp db2jcc4.jar ${NFS_STORAGE_POD}:/var/nfs-data/resources/
sleep 1m
## Create yaml file for b2bi PVs
cat << EOF > b2bi-storage.yaml
kind: PersistentVolume
apiVersion: v1
metadata:
  name: resources
  labels:
    intent: resources
spec:
  storageClassName: "ibmc-file-gold"
  accessModes:
    - ReadOnlyMany
  capacity: 
    storage: 100Mi
  persistentVolumeReclaimPolicy: "Delete"
  nfs:
    server: ${NFS_SERVER_NAME}
    path: ${NFS_SERVER_PATH}/resources/

---
kind: PersistentVolume
apiVersion: v1
metadata:
  name: logs
  labels:
    intent: logs
spec:
  storageClassName: "ibmc-file-gold"
  accessModes:
    - ReadWriteMany
  capacity: 
    storage: 500Mi
  persistentVolumeReclaimPolicy: "Delete"
  nfs:
    server: ${NFS_SERVER_NAME}
    path: ${NFS_SERVER_PATH}/logs/

---
kind: PersistentVolume
apiVersion: v1
metadata:
  name: documents
  labels:
    intent: documents
spec:
  storageClassName: "ibmc-file-gold"
  accessModes:
    - ReadWriteMany
  capacity: 
    storage: 500Mi
  persistentVolumeReclaimPolicy: "Delete"
  nfs:
    server: ${NFS_SERVER_NAME}
    path: ${NFS_SERVER_PATH}/documents/
EOF
## Provision Persistent volumes for B2Bi. 
envsubst < b2bi-storage.yaml | oc create -f -
## Create yaml file for B2Bi secrets.
cat << EOF > b2bi-secrets.yaml
apiVersion: v1
kind: Secret
metadata:
  name: b2b-system-passphrase-secret
type: Opaque
stringData:
  SYSTEM_PASSPHRASE: password

---

apiVersion: v1
kind: Secret
metadata:
  name: b2b-db-secret
type: Opaque
stringData:
  DB_USER: db2inst1
  DB_PASSWORD: db2inst1
  
---

apiVersion: v1
kind: Secret
metadata:
  name: b2b-jms-secret
type: Opaque
stringData:
  JMS_USERNAME: app
  JMS_PASSWORD: passw0rd
  JMS_KEYSTORE_PASSWORD: passw0rd
  JMS_TRUSTSTORE_PASSWORD: passw0rd

---
apiVersion: v1
kind: Secret
metadata:
  name: b2b-liberty-secret
type: Opaque
stringData:
  LIBERTY_KEYSTORE_PASSWORD: password
EOF
## Provision secrets.
envsubst < b2bi-secrets.yaml | oc create -f -
## Create entitlement secret.
cat <<\EOF > entitledregistry.sh
#!/bin/bash
## To read env.sh file.
source $(dirname $(realpath ${0}))/env.sh
oc create secret docker-registry entitled-registry \
--docker-username=cp \
--docker-password=${APIKEY} \
--docker-email=${EMAIL} \
--docker-server=cp.icr.io -n ${PROJECT_NAME}
EOF
## Read api token from env.sh file for entitlement of certified containers.
chmod 755 entitledregistry.sh ; ./entitledregistry.sh
## Create auto-scaler files
cat << EOF > autoscalers.yaml
kind: HorizontalPodAutoscaler
apiVersion: autoscaling/v2beta2
metadata:
  name: ac-auto-scaler
  namespace: ${PROJECT_NAME}
spec:
  scaleTargetRef:
    kind: StatefulSet
    name: sterling-fg-b2bi-ac-server
    apiVersion: apps/v1
  minReplicas: 1
  maxReplicas: 2
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 90

---
kind: HorizontalPodAutoscaler
apiVersion: autoscaling/v2beta2
metadata:
  name: asi-auto-scaler
  namespace: ${PROJECT_NAME}
spec:
  scaleTargetRef:
    kind: StatefulSet
    name: sterling-fg-b2bi-asi-server
    apiVersion: apps/v1
  minReplicas: 1
  maxReplicas: 2
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 90
EOF
## Identify DB2 and MQ's ClusterIP addresses and ROKS's Ingress Subdomain
export DB2_IP=$(oc get svc db2-ci -n ${DB2_NAME} -o jsonpath='{.spec.clusterIP}')
export MQ_IP=$(oc get svc mq-data -n ${MQ_NAME} -o jsonpath='{.spec.clusterIP}')
export INGRESS_SUBDOMAIN=$(oc get IngressController default -n openshift-ingress-operator -o jsonpath='{.status.domain}')
# Download/extract Helm Chart version 2.0.5 (latest as of the writing)
wget https://github.com/IBM/charts/raw/master/repo/ibm-helm/ibm-b2bi-prod-2.0.7.tgz
tar xvf ibm-b2bi-prod-2.0.7.tgz
## Setup SCC and RBAC for B2Bi
(cd $PROJECT_DIR/ibm-b2bi-prod/ibm_cloud_pak/pak_extensions/pre-install/clusterAdministration/ ; chmod 755 createSecurityClusterPrereqs.sh ; ./createSecurityClusterPrereqs.sh)
(cd $PROJECT_DIR/ibm-b2bi-prod/ibm_cloud_pak/pak_extensions/pre-install/namespaceAdministration/ ; chmod 755 createSecurityNamespacePrereqs.sh ; ./createSecurityNamespacePrereqs.sh ${PROJECT_NAME})
## Move edited values file to the helm chart directory.
(mv $PROJECT_DIR/ibm-b2bi-prod/values.yaml $PROJECT_DIR/ibm-b2bi-prod/values.yaml.orig)
(cp $PROJECT_DIR/edited-values.yaml $PROJECT_DIR/ibm-b2bi-prod/values.yaml)
# cd ibm-b2bi-prod
## Deploy Helm chart.
envsubst < $PROJECT_DIR/ibm-b2bi-prod/values.yaml | helm install sterling-fg $PROJECT_DIR/ibm-b2bi-prod --timeout 120m0s --namespace ${PROJECT_NAME} --values -